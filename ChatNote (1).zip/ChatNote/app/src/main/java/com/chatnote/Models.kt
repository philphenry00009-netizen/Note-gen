package com.chatnote

import java.util.concurrent.atomic.AtomicLong

enum class Speaker(val label: String) { USER("User"), AI("AI"), UNKNOWN("Unknown") }

data class OcrLine(val text: String, val left: Int, val top: Int, val right: Int, val bottom: Int)
data class FrameResult(val timeMs: Long, val width: Int, val height: Int, val lines: List<OcrLine>)
data class Block(val id: Long, val timeMs: Long, val speaker: Speaker, val text: String)

data class Settings(
    val intervalMs: Long = 1000,          // frame sampling interval
    val changeThreshold: Double = 1.0,    // skip OCR when frame barely changed (0 = OCR every sample)
    val cropTopPct: Float = 0.07f,        // status bar
    val cropBottomPct: Float = 0.12f,     // keyboard / input box
    val userOnRight: Boolean = true,      // user bubbles right-aligned?
    val rightEdgeRatio: Float = 0.18f,    // text starting right of this x-ratio counts as "right side"
    val similarity: Double = 0.82,        // dedupe threshold
    val includeTimestamps: Boolean = false,
)

object Ids {
    private val n = AtomicLong()
    fun next() = n.incrementAndGet()
}
