package com.chatnote

import kotlin.math.max
import kotlin.math.min

/**
 * Merges per-frame blocks into one chronological list.
 * Blocks already seen (fuzzy match) are not added again; if the new copy is longer
 * (earlier copy was clipped by the screen edge) it replaces the old text.
 * New blocks are inserted relative to matched "anchor" blocks, so scrolling in either direction works.
 */
object Deduper {
    private const val WINDOW = 80
    private val nonWord = Regex("[^\\p{L}\\p{N}]+")

    fun norm(t: String) = t.lowercase().replace(nonWord, " ").trim()

    fun merge(frames: List<FrameResult>, s: Settings): MutableList<Block> {
        val global = mutableListOf<Block>()
        val cache = mutableListOf<String>()

        fun add(at: Int, b: Block) { global.add(at, b); cache.add(at, norm(b.text)) }
        fun find(nb: String): Int {
            for (i in global.lastIndex downTo max(0, global.size - WINDOW))
                if (similar(cache[i], nb, s.similarity)) return i
            return -1
        }
        fun upgrade(i: Int, b: Block) {
            val n = norm(b.text)
            if (n.length > cache[i].length) {
                global[i] = global[i].copy(text = b.text, speaker = if (global[i].speaker == Speaker.UNKNOWN) b.speaker else global[i].speaker)
                cache[i] = n
            }
        }

        for (f in frames) {
            val fb = TextCleaner.frameToBlocks(f, s)
            if (fb.isEmpty()) continue
            val norms = fb.map { norm(it.text) }
            val matches = norms.map { find(it) }
            val first = matches.indexOfFirst { it >= 0 }
            if (first < 0) { fb.forEach { add(global.size, it) }; continue }

            var shift = 0
            var last = matches[first]
            for (i in first until fb.size) {
                val m = matches[i]
                if (m >= 0) { last = m + shift; upgrade(last, fb[i]) }
                else { add(last + 1, fb[i]); last += 1; shift += 1 }
            }
            var at = matches[first]            // blocks above the first anchor (scrolled up)
            for (i in 0 until first) { add(at, fb[i]); at++ }
        }
        return global
    }

    /** Fuzzy match that also treats a clipped bubble (prefix or suffix of the full text) as a duplicate. */
    fun similar(a: String, b: String, th: Double): Boolean {
        if (a == b) return true
        val (s, l) = if (a.length <= b.length) a to b else b to a
        if (s.length < 12) return false
        val n = min(s.length, 300)
        return ratio(s.take(n), l.take(n)) >= th || ratio(s.takeLast(n), l.takeLast(n)) >= th
    }

    private fun ratio(a: String, b: String): Double {
        val m = max(a.length, b.length)
        if (m == 0) return 1.0
        var prev = IntArray(b.length + 1) { it }
        var cur = IntArray(b.length + 1)
        for (i in 1..a.length) {
            cur[0] = i
            for (j in 1..b.length) {
                val c = if (a[i - 1] == b[j - 1]) 0 else 1
                cur[j] = min(min(cur[j - 1] + 1, prev[j] + 1), prev[j - 1] + c)
            }
            val t = prev; prev = cur; cur = t
        }
        return 1.0 - prev[b.length].toDouble() / m
    }
}
