package com.chatnote

import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

fun fmtTime(ms: Long): String { val s = ms / 1000; return "%d:%02d".format(s / 60, s % 60) }

object MarkdownCompiler {
    fun compile(blocks: List<Block>, title: String, timestamps: Boolean): String {
        val sb = StringBuilder()
        val date = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US).format(Date())
        sb.append("# ").appendLine(title).appendLine()
        sb.appendLine("_Extracted on-device · ${date}_").appendLine().appendLine("---").appendLine()
        var last: Speaker? = null
        for (b in blocks) {
            if (b.text.isBlank()) continue
            if (b.speaker != last) {
                sb.append("### ").append(b.speaker.label)
                if (timestamps) sb.append("  `").append(fmtTime(b.timeMs)).append('`')
                sb.appendLine().appendLine()
                last = b.speaker
            }
            sb.appendLine(b.text.trim()).appendLine()
        }
        return sb.toString()
    }
}
