package com.chatnote

import android.graphics.Bitmap
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlinx.coroutines.tasks.await

/** 100% on-device ML Kit OCR. */
class OcrEngine : AutoCloseable {
    private val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)

    suspend fun recognize(bmp: Bitmap, timeMs: Long): FrameResult {
        val result = recognizer.process(InputImage.fromBitmap(bmp, 0)).await()
        val lines = result.textBlocks.flatMap { it.lines }.mapNotNull { l ->
            l.boundingBox?.let { OcrLine(l.text, it.left, it.top, it.right, it.bottom) }
        }.sortedBy { it.top }
        return FrameResult(timeMs, bmp.width, bmp.height, lines)
    }

    override fun close() = recognizer.close()
}
