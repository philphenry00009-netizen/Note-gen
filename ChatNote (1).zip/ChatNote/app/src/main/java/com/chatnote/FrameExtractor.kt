package com.chatnote

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Color
import android.media.MediaMetadataRetriever
import android.net.Uri
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import kotlin.math.abs

class SampledFrame(val timeMs: Long, val bitmap: Bitmap, val progress: Float)

/** Samples one frame per interval and drops frames that look identical to the last kept frame. */
class FrameExtractor(context: Context, uri: Uri) : AutoCloseable {
    private val retriever = MediaMetadataRetriever().apply { setDataSource(context, uri) }
    val durationMs: Long =
        retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L

    fun frames(intervalMs: Long, changeThreshold: Double): Flow<SampledFrame> = flow {
        var t = 0L
        var prev: IntArray? = null
        while (t <= durationMs) {
            val bmp = retriever.getFrameAtTime(t * 1000, MediaMetadataRetriever.OPTION_CLOSEST)
            if (bmp != null) {
                val sig = signature(bmp)
                val p = prev
                if (p == null || diff(p, sig) > changeThreshold) {
                    prev = sig
                    emit(SampledFrame(t, bmp, if (durationMs > 0) t.toFloat() / durationMs else 1f))
                } else bmp.recycle()
            }
            t += intervalMs
        }
    }.flowOn(Dispatchers.IO)

    private fun signature(b: Bitmap): IntArray {
        val w = 48; val h = 96
        val s = Bitmap.createScaledBitmap(b, w, h, true)
        val px = IntArray(w * h)
        s.getPixels(px, 0, w, 0, 0, w, h)
        if (s !== b) s.recycle()
        return IntArray(px.size) { (Color.red(px[it]) * 3 + Color.green(px[it]) * 6 + Color.blue(px[it])) / 10 }
    }

    private fun diff(a: IntArray, b: IntArray): Double {
        var sum = 0L
        for (i in a.indices) sum += abs(a[i] - b[i])
        return sum.toDouble() / a.size
    }

    override fun close() = retriever.release()
}
