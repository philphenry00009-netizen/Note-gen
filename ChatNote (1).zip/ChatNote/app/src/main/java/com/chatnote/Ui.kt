package com.chatnote

import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

@Composable
fun App(vm: MainViewModel) {
    when (vm.screen) { Screen.IMPORT -> ImportScreen(vm); Screen.REVIEW -> ReviewScreen(vm) }
}

@Composable
private fun LabeledSlider(label: String, value: Float, range: ClosedFloatingPointRange<Float>, onChange: (Float) -> Unit) {
    Column { Text(label, style = MaterialTheme.typography.bodyMedium); Slider(value, onChange, valueRange = range) }
}

@Composable
fun ImportScreen(vm: MainViewModel) {
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { it?.let(vm::setVideo) }
    val s = vm.settings
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Text("Chat → Markdown", style = MaterialTheme.typography.headlineSmall)
        Button(onClick = { picker.launch(arrayOf("video/*")) }, enabled = !vm.busy) {
            Text(if (vm.videoUri == null) "Select screen recording" else "Change video")
        }
        if (vm.videoName.isNotEmpty()) Text(vm.videoName)

        LabeledSlider("Sample every ${"%.1f".format(s.intervalMs / 1000f)} s (lower = safer for fast scrolling)",
            s.intervalMs.toFloat(), 500f..3000f) { vm.settings = s.copy(intervalMs = it.toLong()) }
        LabeledSlider("Ignore top ${(s.cropTopPct * 100).toInt()}% (status bar)",
            s.cropTopPct, 0f..0.2f) { vm.settings = s.copy(cropTopPct = it) }
        LabeledSlider("Ignore bottom ${(s.cropBottomPct * 100).toInt()}% (keyboard / input)",
            s.cropBottomPct, 0f..0.4f) { vm.settings = s.copy(cropBottomPct = it) }
        LabeledSlider("User/AI split at ${(s.rightEdgeRatio * 100).toInt()}% of screen width",
            s.rightEdgeRatio, 0.05f..0.4f) { vm.settings = s.copy(rightEdgeRatio = it) }
        LabeledSlider("Duplicate similarity ${(s.similarity * 100).toInt()}%",
            s.similarity.toFloat(), 0.6f..0.95f) { vm.settings = s.copy(similarity = it.toDouble()) }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Switch(s.userOnRight, { vm.settings = s.copy(userOnRight = it) }); Spacer(Modifier.width(8.dp))
            Text("User bubbles are on the right")
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Switch(s.includeTimestamps, { vm.settings = s.copy(includeTimestamps = it) }); Spacer(Modifier.width(8.dp))
            Text("Include video timestamps in note")
        }

        if (vm.busy) {
            LinearProgressIndicator(progress = { vm.progress }, modifier = Modifier.fillMaxWidth())
            OutlinedButton(onClick = vm::cancel) { Text("Cancel") }
        } else {
            Button(onClick = vm::process, enabled = vm.videoUri != null) { Text("Extract text") }
        }
        if (vm.status.isNotEmpty()) Text(vm.status)
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ReviewScreen(vm: MainViewModel) {
    var tab by remember { mutableIntStateOf(0) }
    val saveMd = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("text/markdown")) { it?.let(vm::export) }
    val saveTxt = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("text/plain")) { it?.let(vm::export) }
    BackHandler { vm.back() }
    Scaffold(topBar = {
        TopAppBar(
            title = { Text("Review") },
            navigationIcon = { TextButton(onClick = vm::back) { Text("Back") } },
            actions = {
                TextButton(onClick = vm::reclean) { Text("Re-clean") }
                TextButton(onClick = { saveMd.launch("chat-note.md") }) { Text(".md") }
                TextButton(onClick = { saveTxt.launch("chat-note.txt") }) { Text(".txt") }
            })
    }) { pad ->
        Column(Modifier.padding(pad)) {
            TabRow(selectedTabIndex = tab) {
                listOf("Blocks", "Raw OCR", "Preview").forEachIndexed { i, t ->
                    Tab(selected = tab == i, onClick = { tab = i }, text = { Text(t) })
                }
            }
            when (tab) { 0 -> BlocksTab(vm); 1 -> RawTab(vm); else -> PreviewTab(vm) }
        }
    }
}

@Composable
fun BlocksTab(vm: MainViewModel) {
    LazyColumn(contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        items(vm.blocks, key = { it.id }) { BlockCard(vm, it) }
        item { OutlinedButton(onClick = { vm.insertAfter(vm.blocks.lastOrNull()?.id) }) { Text("+ Add block at end") } }
    }
}

@Composable
fun BlockCard(vm: MainViewModel, b: Block) {
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(10.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                AssistChip(onClick = { vm.cycleSpeaker(b.id) }, label = { Text(b.speaker.label) })
                Spacer(Modifier.width(8.dp))
                Text(fmtTime(b.timeMs), style = MaterialTheme.typography.labelSmall)
            }
            OutlinedTextField(value = b.text, onValueChange = { vm.updateText(b.id, it) }, modifier = Modifier.fillMaxWidth())
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                TextButton(onClick = { vm.mergePrev(b.id) }) { Text("↑Merge") }
                TextButton(onClick = { vm.mergeNext(b.id) }) { Text("↓Merge") }
                TextButton(onClick = { vm.insertAfter(b.id) }) { Text("+Add") }
                TextButton(onClick = { vm.delete(b.id) }) { Text("Delete") }
            }
        }
    }
}

@Composable
fun RawTab(vm: MainViewModel) {
    LazyColumn(contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        items(vm.raw) { f ->
            Column {
                Text(fmtTime(f.timeMs), fontWeight = FontWeight.Bold)
                Text(f.lines.joinToString("\n") { it.text })
                HorizontalDivider(Modifier.padding(top = 8.dp))
            }
        }
    }
}

@Composable
fun PreviewTab(vm: MainViewModel) {
    SelectionContainer {
        Text(vm.markdown(), fontFamily = FontFamily.Monospace,
            modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(12.dp))
    }
}
