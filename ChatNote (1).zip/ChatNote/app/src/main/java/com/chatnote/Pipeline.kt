package com.chatnote

import android.content.Context
import android.net.Uri
import kotlinx.coroutines.flow.collect

class Pipeline(private val ctx: Context) {
    /** Video -> sampled frames -> raw OCR per frame. Slow step; run once. */
    suspend fun extractRaw(uri: Uri, s: Settings, onProgress: (Float) -> Unit): List<FrameResult> {
        val out = mutableListOf<FrameResult>()
        FrameExtractor(ctx, uri).use { ex ->
            OcrEngine().use { ocr ->
                ex.frames(s.intervalMs, s.changeThreshold).collect { f ->
                    try { out += ocr.recognize(f.bitmap, f.timeMs) } finally { f.bitmap.recycle() }
                    onProgress(f.progress)
                }
            }
        }
        return out
    }
}
