package com.chatnote

import android.app.Application
import android.net.Uri
import android.provider.OpenableColumns
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

enum class Screen { IMPORT, REVIEW }

class MainViewModel(app: Application) : AndroidViewModel(app) {
    var screen by mutableStateOf(Screen.IMPORT)
        private set
    var videoUri by mutableStateOf<Uri?>(null)
        private set
    var videoName by mutableStateOf("")
        private set
    var settings by mutableStateOf(Settings())
    var busy by mutableStateOf(false)
        private set
    var progress by mutableStateOf(0f)
        private set
    var status by mutableStateOf("")
        private set
    var raw by mutableStateOf<List<FrameResult>>(emptyList())
        private set
    val blocks = mutableStateListOf<Block>()
    private var job: Job? = null

    fun setVideo(uri: Uri) {
        videoUri = uri
        videoName = getApplication<Application>().contentResolver
            .query(uri, null, null, null, null)?.use { c ->
                val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (c.moveToFirst() && i >= 0) c.getString(i) else null
            } ?: uri.lastPathSegment.orEmpty()
    }

    fun process() {
        val uri = videoUri ?: return
        job = viewModelScope.launch {
            busy = true; progress = 0f; status = "Reading and OCR-ing frames…"
            try {
                val frames = withContext(Dispatchers.Default) {
                    Pipeline(getApplication()).extractRaw(uri, settings) { progress = it }
                }
                raw = frames
                rebuild()
                status = ""
                screen = Screen.REVIEW
            } catch (e: CancellationException) {
                status = "Cancelled"; throw e
            } catch (e: Exception) {
                status = "Failed: ${e.message}"
            } finally { busy = false }
        }
    }

    fun cancel() { job?.cancel() }
    fun back() { screen = Screen.IMPORT }

    /** Re-run cleaning + dedupe over stored raw OCR with current settings (discards manual edits). */
    fun reclean() = rebuild()
    private fun rebuild() { blocks.clear(); blocks.addAll(Deduper.merge(raw, settings)) }

    private fun idx(id: Long) = blocks.indexOfFirst { it.id == id }

    fun updateText(id: Long, t: String) { val i = idx(id); if (i >= 0) blocks[i] = blocks[i].copy(text = t) }
    fun cycleSpeaker(id: Long) {
        val i = idx(id); if (i < 0) return
        val next = when (blocks[i].speaker) { Speaker.USER -> Speaker.AI; Speaker.AI -> Speaker.UNKNOWN; Speaker.UNKNOWN -> Speaker.USER }
        blocks[i] = blocks[i].copy(speaker = next)
    }
    fun delete(id: Long) { val i = idx(id); if (i >= 0) blocks.removeAt(i) }
    fun mergeNext(id: Long) {
        val i = idx(id); if (i < 0 || i >= blocks.lastIndex) return
        blocks[i] = blocks[i].copy(text = blocks[i].text.trimEnd() + "\n" + blocks[i + 1].text)
        blocks.removeAt(i + 1)
    }
    fun mergePrev(id: Long) { val i = idx(id); if (i > 0) mergeNext(blocks[i - 1].id) }
    fun insertAfter(id: Long?) {
        val i = if (id == null) -1 else idx(id)
        val prev = blocks.getOrNull(i)
        val sp = if (prev?.speaker == Speaker.USER) Speaker.AI else Speaker.USER
        blocks.add(i + 1, Block(Ids.next(), prev?.timeMs ?: 0L, sp, ""))
    }

    fun markdown(): String = MarkdownCompiler.compile(
        blocks, videoName.substringBeforeLast('.').ifBlank { "Chat note" }, settings.includeTimestamps
    )

    fun export(uri: Uri) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                getApplication<Application>().contentResolver.openOutputStream(uri, "wt")
                    ?.use { it.write(markdown().toByteArray()) }
                status = "Saved"
            } catch (e: Exception) { status = "Save failed: ${e.message}" }
        }
    }
}
