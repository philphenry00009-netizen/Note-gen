package com.chatnote

/** Turns one OCR frame into speaker-tagged blocks, dropping junk UI text. */
object TextCleaner {
    private val junk = listOf(
        Regex("""\d{1,2}[:.]\d{2}(\s?[AaPp]\.?[Mm]\.?)?"""),               // clock / message times
        Regex("""\d{1,3}\s?%"""),                                            // battery
        Regex("""(?i)(lte|5g|4g|3g|wifi|wi-fi|volte)"""),                    // network
        Regex("""(?i)(today|yesterday|delivered|seen|typing\.*|message|send|copy|share|regenerate|edited)"""),
        Regex("""(?i)(type a message.*|ask anything.*|message claude.*|reply to claude.*|message chatgpt.*)"""),
        Regex("""[^\p{L}\p{N}]{1,3}"""),                                     // stray symbols / icons
    )
    private val bullet = Regex("""^([•·●▪\-*]|\d{1,2}[.)])\s""")

    fun tidy(t: String) = t.replace('\u00A0', ' ').replace(Regex("\\s+"), " ").trim()
    fun isJunk(t: String) = t.length < 2 || junk.any { it.matches(t.trim()) }

    fun frameToBlocks(f: FrameResult, s: Settings): List<Block> {
        val top = f.height * s.cropTopPct
        val bottom = f.height * (1f - s.cropBottomPct)
        val lines = f.lines
            .filter { ((it.top + it.bottom) / 2f) in top..bottom }
            .map { it.copy(text = tidy(it.text)) }
            .filter { !isJunk(it.text) }
            .sortedBy { it.top }

        val out = mutableListOf<Block>()
        var cur = StringBuilder()
        var curSpeaker = Speaker.UNKNOWN
        var prev: OcrLine? = null

        fun flush() {
            if (cur.isNotBlank()) out += Block(Ids.next(), f.timeMs, curSpeaker, cur.toString().trim())
            cur = StringBuilder()
        }

        for (l in lines) {
            val rightSide = l.left.toFloat() / f.width > s.rightEdgeRatio
            val sp = if (rightSide == s.userOnRight) Speaker.USER else Speaker.AI
            val p = prev
            val newBlock = p == null || sp != curSpeaker || (l.top - p.bottom) > 0.7f * (p.bottom - p.top)
            if (newBlock) { flush(); curSpeaker = sp }
            else cur.append(if (bullet.containsMatchIn(l.text)) "\n" else " ")
            cur.append(l.text)
            prev = l
        }
        flush()
        return out
    }
}
